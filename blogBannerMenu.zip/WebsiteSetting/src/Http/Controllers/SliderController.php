<?php

namespace Modules\WebsiteSetting\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
// use App\Models\Slider;
// use App\Models\SliderImages;


use Modules\WebsiteSetting\Models\Slider;
use Modules\WebsiteSetting\Models\SliderImages;

use Illuminate\Http\Request;
use ApiHelper;


class SliderController extends Controller
{

    public $page = 'web_slider';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';

    public function index(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $data_list = Slider::all();

        $res = [
            'data_list' => $data_list
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $slider_data = $request->only(['sliders_title', 'carousel_item', 'carousel_width', 'status']);

        $data = Slider::create($slider_data);

        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_SLIDER_ADD');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_SLIDER_ADD');
    }

    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        $data_list = Slider::where('sliders_id', $request->sliders_id)->first();
        return ApiHelper::JSON_RESPONSE(true, $data_list, '');
    }

    public function update(Request $request)
    {


        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $slider_update_data = $request->only(['sliders_title', 'carousel_item', 'carousel_width', 'status']);


        $data = Slider::where('sliders_id', $request->sliders_id)->update($slider_update_data);

        if ($slider_update_data)
            return ApiHelper::JSON_RESPONSE(true, $slider_update_data, 'SUCCESS_SLIDER_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_SLIDER_UPDATE');
    }



    public function changeStatus(Request $request)
    {
        $api_token = $request->api_token;
        $sliders_id = $request->sliders_id;
        $sub_data = Slider::find($sliders_id);
        $sub_data->status = ($sub_data->status == 0) ? 1 : 0;
        $sub_data->save();

        return ApiHelper::JSON_RESPONSE(true, $sub_data, 'SUCCESS_STATUS_UPDATE');
    }
}
