<?php

namespace Modules\WebsiteSetting\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Modules\WebsiteSetting\Models\PostAuthor;
use Modules\WebsiteSetting\Models\Super\SuperPostAuthor;


use Illuminate\Support\Str;

use ApiHelper;


class PostAuthorController extends Controller
{
    public $page = 'blog_setting';
    public $landingpage = 'super_blog_setting';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? (int) $request->perPage : ApiHelper::perPageItem();
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;
        $language = $request->language;



        if ($userType == 'subscriber') {
            $data_query = PostAuthor::query();
        } else {

            $data_query = SuperPostAuthor::query();
        }

        if (!empty($search)) {
            $data_query = $data_query->where("author_name", "LIKE", "%{$search}%");
        }

        // if (!empty($search))
        //     $data_query = $data_query->where("post_title","LIKE", "%{$search}%");

        /* order by sorting */
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('author_id', 'ASC');
        }

        $skip = ($current_page == 1) ? 0 : (int) ($current_page - 1) * $perPage;

        $user_count = $data_query->count();

        $data_list = $data_query->skip($skip)->take($perPage)->get();

        $data_list = $data_list->map(function ($data) use ($language) {

            $data->image = ApiHelper::getFullImageUrl($data->author_image);
            //  $data->status = ($data->status == 1) ? "active" : "deactive";

            return $data;
        });

        // $data->feature_icon = ApiHelper::getFullImageUrl($data->feature_icon);

        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int) $user_count / (int) $perPage),
            'per_page' => $perPage,
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }



    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        if ($userType == 'subscriber') {
            // store form 
            $saveData =  $request->only(['author_name', 'author_details', 'author_designation', 'author_image']);
            if ($saveData['author_image'] != '') {
                ApiHelper::image_upload_with_crop($api_token, $saveData['author_image'], 1, 'postAuthor', '', false);
            }

            $postAuthor  = PostAuthor::create($saveData);
        } else {
            // store form 
            $saveData =  $request->only(['author_name', 'author_details', 'author_designation', 'author_image']);
            if ($saveData['author_image'] != '') {
                ApiHelper::image_upload_with_crop($api_token, $saveData['author_image'], 1, 'postAuthor', '', false);
            }

            $postAuthor  = SuperPostAuthor::create($saveData);
        }





        return ApiHelper::JSON_RESPONSE(true, $postAuthor, 'SUCCESS_POST_AUTHOR_ADD');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {

            $data_list = PostAuthor::find($request->author_id);
            if (!empty($data_list))
                $data_list->image = ApiHelper::getFullImageUrl($data_list->author_image, 'index-list');
        } else {


            $data_list = SuperPostAuthor::find($request->author_id);
            if (!empty($data_list))
                $data_list->image = ApiHelper::getFullImageUrl($data_list->author_image, 'index-list');
        }



        $data = [
            'data_list' => $data_list,

        ];


        return ApiHelper::JSON_RESPONSE(true, $data, '');
    }

    //This Function is used to update the particular plan data
    public function update(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $author_id = $request->author_id;


        if ($userType == 'subscriber') {
            // store form 
            $saveData =  $request->only(['author_name', 'author_details', 'author_designation', 'status', 'author_image']);

            if ($saveData['author_image'] != '') {
                ApiHelper::image_upload_with_crop($api_token, $saveData['author_image'], 1, 'postAuthor', '', false);
            }

            $postAuthor = PostAuthor::where('author_id', $author_id)->update($saveData);
        } else {



            // store form 
            $saveData =  $request->only(['author_name', 'author_details', 'author_designation', 'status', 'author_image']);

            if ($saveData['author_image'] != '') {
                ApiHelper::image_upload_with_crop($api_token, $saveData['author_image'], 1, 'postAuthor', '', false);
            }

            $postAuthor = SuperPostAuthor::where('author_id', $author_id)->update($saveData);
        }



        return ApiHelper::JSON_RESPONSE(true, $postAuthor, 'SUCCESS_POST_AUTHOR_UPDATE');
    }



    //This Function is used to get the change the form status
    public function changeStatus(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {

            $infoData = PostAuthor::find($request->author_id);
            $infoData->status = ($infoData->status == 0) ? 1 : 0;
            $infoData->save();
        } else {

            $infoData = SuperPostAuthor::find($request->author_id);
            $infoData->status = ($infoData->status == 0) ? 1 : 0;
            $infoData->save();
        }


        return ApiHelper::JSON_RESPONSE(true, $infoData, 'SUCCESS_STATUS_UPDATE');
    }
}
