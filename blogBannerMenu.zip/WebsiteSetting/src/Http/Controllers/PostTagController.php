<?php

namespace Modules\WebsiteSetting\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Modules\WebsiteSetting\Models\PostCategory;
use Modules\WebsiteSetting\Models\PostToCategory;
use Modules\WebsiteSetting\Models\PostTag;
use Modules\WebsiteSetting\Models\Super\SuperPostTag;
use Illuminate\Support\Str;


use ApiHelper;


class PostTagController extends Controller
{
    public $page = 'blog_setting';
    public $landingpage = 'super_blog_setting';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? (int) $request->perPage : ApiHelper::perPageItem();
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;
        $language = $request->language;


        if ($userType == 'subscriber') {
            $data_query = PostTag::query();
        } else {

            $data_query = SuperPostTag::query();
        }

        if (!empty($search)) {
            $data_query = $data_query->where("tags_name", "LIKE", "%{$search}%");
        }

        // if (!empty($search))
        //     $data_query = $data_query->where("post_title","LIKE", "%{$search}%");

        /* order by sorting */
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('tags_id', 'ASC');
        }

        $skip = ($current_page == 1) ? 0 : (int) ($current_page - 1) * $perPage;

        $user_count = $data_query->count();

        $data_list = $data_query->skip($skip)->take($perPage)->get();

        $data_list = $data_list->map(function ($data) use ($language) {


            //  $data->status = ($data->status == 1) ? "active" : "deactive";

            return $data;
        });

        // $data->feature_icon = ApiHelper::getFullImageUrl($data->feature_icon);

        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int) $user_count / (int) $perPage),
            'per_page' => $perPage,
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }



    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        if ($userType == 'subscriber') {
            // store form 
            $saveData =  $request->only(['tags_name']);
            $saveData['tags_slug'] = Str::slug($request->tags_name);
            //    return ApiHelper::JSON_RESPONSE(true, $saveData, 'SUCCESS_POST_TAG_ADD');
            $tags = PostTag::where('tags_name', $request->tags_name)->first();

            if (empty($tags)) {
                $postCategory = PostTag::create($saveData);
            } else {
                return ApiHelper::JSON_RESPONSE(false, [], 'TAGS_NAME_ALREADY_EXIST');
            }
        } else {
            // store form 
            $saveData =  $request->only(['tags_name']);

            $tags = SuperPostTag::where('tags_name', $request->tags_name)->first();

            if (empty($tags)) {
                $postCategory = SuperPostTag::create($saveData);
            } else {
                return ApiHelper::JSON_RESPONSE(false, [], 'TAGS_NAME_ALREADY_EXIST');
            }
        }



        //  $postCategory = PostTag::create($saveData);

        return ApiHelper::JSON_RESPONSE(true, $postCategory, 'SUCCESS_POST_TAG_ADD');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);

        if ($userType == 'subscriber') {
            $data_list = PostTag::find($request->tags_id);
        } else {
            $data_list = SuperPostTag::find($request->tags_id);
        }


        $data = [
            'data_list' => $data_list,

        ];


        return ApiHelper::JSON_RESPONSE(true, $data, '');
    }

    //This Function is used to update the particular plan data
    public function update(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $tags_id = $request->tags_id;


        if ($userType == 'subscriber') {
            // store form 
            $saveData =  $request->only(['tags_name', 'status']);
            $saveData['tags_slug'] = Str::slug($request->tags_name);
            $postCategory = PostTag::where('tags_id', $tags_id)->update($saveData);
        } else {

            // store form 
            $saveData =  $request->only(['tags_name', 'status']);

            $postCategory = SuperPostTag::where('tags_id', $tags_id)->update($saveData);
        }





        return ApiHelper::JSON_RESPONSE(true, $postCategory, 'SUCCESS_POST_TAG_UPDATE');
    }



    //This Function is used to get the change the form status
    public function changeStatus(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $infoData = PostTag::find($request->tags_id);
            $infoData->status = ($infoData->status == 0) ? 1 : 0;
            $infoData->save();
        } else {
            $infoData = SuperPostTag::find($request->tags_id);
            $infoData->status = ($infoData->status == 0) ? 1 : 0;
            $infoData->save();
        }


        return ApiHelper::JSON_RESPONSE(true, $infoData, 'SUCCESS_STATUS_UPDATE');
    }
}
