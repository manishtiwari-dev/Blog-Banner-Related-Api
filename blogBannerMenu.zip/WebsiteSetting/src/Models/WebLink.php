<?php

namespace Modules\WebsiteSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;



class WebLink extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $primaryKey = 'link_id';
    protected $guarded = ['link_id'];

    public function getTable()
    {
        return config('dbtable.web_links');
    }
}
