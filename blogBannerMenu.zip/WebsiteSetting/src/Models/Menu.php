<?php

namespace Modules\WebsiteSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\MenuGroup;

class Menu extends Model
{
    use HasFactory;

    protected $primaryKey = "menu_id";

    protected $guarded = [

        'menu_id',
    ];


    public function getTable()
    {
        return config('dbtable.web_menu');
    }

    public function bannerGroup()
    {
        return $this->belongsTo(MenuGroup::class, 'group_id', 'group_id');
    }

    public function menuDetails()
    {
        return $this->hasMany(MenuDetails::class, 'menu_id', 'menu_id');
    }
}
