<?php

namespace Modules\WebsiteSetting\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\Ecommerce\Models\SeoMeta;

class WebPagesDescription extends Model
{
    use HasFactory;

   // protected $table = "website_setting";
   protected $primaryKey = 'page_description_id';
   protected $guarded = ['page_description_id'];

    public function getTable() 
    {
        return config('dbtable.web_pages_description');
    }

    public function seo(){
        return $this->hasOne(SeoMeta::class, 'reference_id','page_description_id')->where('page_type',3);
    }
}
