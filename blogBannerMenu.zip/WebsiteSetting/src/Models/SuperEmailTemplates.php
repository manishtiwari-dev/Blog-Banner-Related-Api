<?php

namespace Modules\WebsiteSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class SuperEmailTemplates extends Model
{
    use HasFactory;

    protected $primaryKey = "template_id";

    public $timestamps = false;

    protected $guarded=[
     'template_id',
    ];
     
    public function getTable()
    {
        return config('dbtable.super_app_email_templates');
    }

    


}
