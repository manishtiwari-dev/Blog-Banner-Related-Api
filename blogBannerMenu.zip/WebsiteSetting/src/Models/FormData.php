<?php

namespace Modules\WebsiteSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FormData extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $primaryKey = 'form_data_id';
    protected $guarded = ['form_data_id'];

    public function getTable()
    {
        return config('dbtable.crm_form_data');
    }

}
