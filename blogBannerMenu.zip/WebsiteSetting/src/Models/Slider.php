<?php

namespace Modules\WebsiteSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\SliderImages;

class Slider extends Model
{
    use HasFactory;

    protected $primaryKey = "sliders_id";

    public $timestamps = false;

    protected $guarded=[
     
     'sliders_id',


    ];
     
    
    public function getTable()
    {
        return config('dbtable.web_sliders');
    }

    public function slider_images(){
        return $this->hasOne(SliderImages::class, 'sliders_id');
    }



}
