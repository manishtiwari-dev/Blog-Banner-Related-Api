<?php

namespace Modules\WebsiteSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\WebFaq;



class WebFaqGroup extends Model
{
    use HasFactory;

    protected $primaryKey = "group_id";

    public $timestamps = false;

    protected $guarded=[
     
     'group_id',


    ];
     
    
    public function getTable()
    {
        return config('dbtable.web_faq_group');
    }

    public function faq_list(){
        return $this->hasMany(WebFaq::class,'group_id');
    }

   


}
