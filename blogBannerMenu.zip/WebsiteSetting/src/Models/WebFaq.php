<?php

namespace Modules\WebsiteSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\WebFaqGroup;

class WebFaq extends Model
{
    use HasFactory;

    protected $primaryKey = "id";

    public $timestamps = false;

    protected $guarded=[
     
     'id',


    ];
     
    
    public function getTable()
    {
        return config('dbtable.web_faq');
    }

    public function faqGroup(){
        return $this->belongsTo(WebFaqGroup::class, 'group_id','group_id');
    }



}
