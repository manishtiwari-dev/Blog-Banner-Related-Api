<?php

namespace Modules\WebsiteSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\PostDescriptions;
use Modules\WebsiteSetting\Models\PostCategory;
use Modules\WebsiteSetting\Models\PostTag;


class Posts extends Model
{
    use HasFactory;

    protected $primaryKey = "post_id";

    public $timestamps = false;

    protected $guarded = [

        'post_id',
    ];


    public function getTable()
    {
        return config('dbtable.web_posts');
    }

    public function descriptionDetails()
    {
        return $this->hasMany(PostDescriptions::class, 'post_id', 'post_id');
    }

    public function post_to_categories()
    {
        return $this->belongsToMany(PostCategory::class, config('dbtable.web_post_to_category'), 'post_id', 'category_id');
    }

    public function post_tag()
    {
        return $this->belongsToMany(PostTag::class,  'tags', 'tags_id');
    }

    public function postToTag()
    {
        return $this->belongsToMany(PostTag::class, config('dbtable.web_post_to_tag'), 'post_id', 'tags_id');
    }
}
