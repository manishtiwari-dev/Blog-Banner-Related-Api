<?php

namespace Modules\WebsiteSetting\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\Super\SuperPostCategory;
use Modules\WebsiteSetting\Models\Super\SuperPostTag;



class LandingPost extends Model
{
    use HasFactory;

    protected $primaryKey = "post_id";

    public $timestamps = false;

    protected $guarded = [

        'post_id',
    ];



    public function getTable()
    {
        return config('dbtable.landing_web_posts');
    }

    public function descriptionDetails()
    {
        return $this->hasMany(LandingPostDescription::class, 'post_id', 'post_id');
    }

    public function post_to_categories()
    {
        return $this->belongsToMany(SuperPostCategory::class, config('dbtable.super_web_post_to_category'), 'post_id', 'category_id');
    }


    public function postToTag()
    {
        return $this->belongsToMany(SuperPostTag::class, config('dbtable.super_web_post_to_tag'), 'post_id', 'tags_id');
    }
}
