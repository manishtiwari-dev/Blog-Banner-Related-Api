<?php

namespace Modules\WebsiteSetting\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\Super\SuperFormField;

class SuperForm extends Model
{
    use HasFactory;

    protected $primaryKey = "form_id";

    public $timestamps = false;

    protected $guarded = [

        'form_id',


    ];



    public function getTable()
    {
        return config('dbtable.super_crm_form');
    }

    public function form_field()
    {
        return $this->hasMany(SuperFormField::class, 'form_id', 'form_id');
    }
}
