<?php

namespace Modules\WebsiteSetting\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WebsiteSettingGroupKey extends Model
{
    use HasFactory;
    public $timestamps = false;
    
   // protected $connection='mysqlSuper';
    //protected $table = "web_settings_group_key";
    protected $primaryKey = 'setting_id';
    protected $guarded = ['setting_id'];



    public function getTable()
    {
       return config('dbtable.web_settings_group_key');
    }
}
