<?php

namespace Modules\WebsiteSetting\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\PostDescriptions;


class SuperPostTocategory extends Model
{
    use HasFactory;

    protected $primaryKey = "post_id";

    public $timestamps = false;

    protected $guarded = [

        'post_id',
    ];


    public function getTable()
    {
        return config('dbtable.super_web_post_to_category');
    }
}
