<?php

namespace Modules\WebsiteSetting\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Industry;

class TemplateIndustry extends Model
{
    use HasFactory;
    protected $connection='mysqlSuper';
    protected $table = "web_templates_industry";
    
    public $timestamps = false;

    // protected $table = "website_setting";

    protected $fillable = [
            'template_id',
            'industry_id',
            
    ];

  
   public function template_details(){
        return $this->belongsTo(Templates::class, 'template_id', 'template_id');
    }

    public function industry_details(){
        return $this->belongsTo(Industry::class, 'industry_id', 'industry_id');
    }


    
}

