<?php

namespace Modules\WebsiteSetting\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\Super\Faq;


class FaqGroup extends Model
{
    use HasFactory;

    protected $primaryKey = "group_id";

    public $timestamps = false;

    protected $guarded=[
     
     'group_id',


    ];
     
    
    public function getTable()
    {
        return config('dbtable.landing_web_faq_group');
    }

    public function faq_list(){
        return $this->hasMany(Faq::class,'group_id');
    }

   


}
