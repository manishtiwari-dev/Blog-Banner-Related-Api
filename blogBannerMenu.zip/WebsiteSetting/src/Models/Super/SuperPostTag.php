<?php

namespace Modules\WebsiteSetting\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\PostDescriptions;


class SuperPostTag extends Model
{
    use HasFactory;

    protected $primaryKey = "tags_id";

    public $timestamps = false;

    protected $guarded = [

        'tags_id',
    ];


    public function getTable()
    {
        return config('dbtable.super_web_post_tags');
    }
}
