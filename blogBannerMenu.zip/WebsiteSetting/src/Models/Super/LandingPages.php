<?php

namespace Modules\WebsiteSetting\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\Super\LandingPagesDescription;


class LandingPages extends Model
{
    use HasFactory;

   // protected $table = "website_setting";
   protected $primaryKey = 'pages_id';
   protected $guarded = ['pages_id'];


    public function getTable() 
    {
        return config('dbtable.landing_web_pages');
    }


    public function page_description(){
        return $this->hasMany(LandingPagesDescription::class, 'pages_id', 'pages_id');
    }

}
