<?php

namespace Modules\WebsiteSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\PostDescriptions;


class PostToCategory extends Model
{
    use HasFactory;

    protected $primaryKey = "post_id";

    public $timestamps = false;

    protected $guarded = [

        'post_id',
    ];


    public function getTable()
    {
        return config('dbtable.web_post_to_category');
    }
}
